using System;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        Double Numero1, Numero2;
        public Form1()
        {
            InitializeComponent();
        }

        private void bntLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Clear();
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if(Numero2 == 0)
            {
                MessageBox.Show("Impossivel Dividir por 0");
                txtNumero2.Focus();
            }
            else
            {
                txtResultado.Text = (Numero1/Numero2).ToString();
            }

        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            txtResultado.Text = (Numero1 * Numero2).ToString();
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            txtResultado.Text = (Numero1 - Numero2).ToString();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            txtResultado.Text = (Numero1 + Numero2).ToString();
        }


        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja mesmo sair?", "Saida", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNumero1.Text, out Numero1))
            {
                MessageBox.Show("A entrada do Numero 1 precisa ser um Numero valido");
                txtNumero1.Focus();
            }
        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNumero2.Text, out Numero2))
            {
                MessageBox.Show("A entrada do Numero 2 precisa ser um Numero valido");
                txtNumero2.Focus();
            }
        }
    }
}
