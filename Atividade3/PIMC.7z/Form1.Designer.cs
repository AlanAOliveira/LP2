﻿namespace PIMC
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblPeso = new Label();
            lblAltura = new Label();
            lblIMC = new Label();
            msktxPeso = new MaskedTextBox();
            msktxAltura = new MaskedTextBox();
            txtIMC = new TextBox();
            btnCalcular = new Button();
            btnLimpar = new Button();
            btnSair = new Button();
            SuspendLayout();
            // 
            // lblPeso
            // 
            lblPeso.AutoSize = true;
            lblPeso.Location = new Point(55, 68);
            lblPeso.Name = "lblPeso";
            lblPeso.Size = new Size(80, 25);
            lblPeso.TabIndex = 0;
            lblPeso.Text = "Peso(Kg)";
            // 
            // lblAltura
            // 
            lblAltura.AutoSize = true;
            lblAltura.Location = new Point(50, 118);
            lblAltura.Name = "lblAltura";
            lblAltura.Size = new Size(85, 25);
            lblAltura.TabIndex = 1;
            lblAltura.Text = "Altura(M)";
            // 
            // lblIMC
            // 
            lblIMC.AutoSize = true;
            lblIMC.Location = new Point(76, 168);
            lblIMC.Name = "lblIMC";
            lblIMC.Size = new Size(44, 25);
            lblIMC.TabIndex = 2;
            lblIMC.Text = "IMC";
            // 
            // msktxPeso
            // 
            msktxPeso.Location = new Point(141, 68);
            msktxPeso.Mask = "000.00";
            msktxPeso.Name = "msktxPeso";
            msktxPeso.Size = new Size(150, 31);
            msktxPeso.TabIndex = 3;
            // 
            // msktxAltura
            // 
            msktxAltura.Location = new Point(141, 115);
            msktxAltura.Mask = "0.00";
            msktxAltura.Name = "msktxAltura";
            msktxAltura.RightToLeft = RightToLeft.No;
            msktxAltura.Size = new Size(150, 31);
            msktxAltura.TabIndex = 4;
            // 
            // txtIMC
            // 
            txtIMC.Enabled = false;
            txtIMC.Location = new Point(141, 165);
            txtIMC.Name = "txtIMC";
            txtIMC.RightToLeft = RightToLeft.No;
            txtIMC.Size = new Size(150, 31);
            txtIMC.TabIndex = 5;
            txtIMC.TextAlign = HorizontalAlignment.Right;
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(371, 63);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(112, 34);
            btnCalcular.TabIndex = 6;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(371, 115);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(112, 34);
            btnLimpar.TabIndex = 7;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(371, 168);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(112, 34);
            btnSair.TabIndex = 8;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(555, 286);
            Controls.Add(btnSair);
            Controls.Add(btnLimpar);
            Controls.Add(btnCalcular);
            Controls.Add(txtIMC);
            Controls.Add(msktxAltura);
            Controls.Add(msktxPeso);
            Controls.Add(lblIMC);
            Controls.Add(lblAltura);
            Controls.Add(lblPeso);
            Name = "Form1";
            Text = "IMC";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblPeso;
        private Label lblAltura;
        private Label lblIMC;
        private MaskedTextBox msktxPeso;
        private MaskedTextBox msktxAltura;
        private TextBox txtIMC;
        private Button btnCalcular;
        private Button btnLimpar;
        private Button btnSair;
    }
}
