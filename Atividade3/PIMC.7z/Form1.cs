namespace PIMC
{
    public partial class Form1 : Form
    {
        double Peso, Altura, IMC;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double.TryParse(msktxPeso.Text, out Peso);
            double.TryParse(msktxAltura.Text, out Altura);
            if (Peso <= 0)
            {
                MessageBox.Show("Peso deve ser ao menos 0");
                msktxPeso.Focus();
            }
            else if (Altura <= 0)
            {
                MessageBox.Show("Altura deve ser ao menos 0");
                msktxAltura.Focus();
            }
            else
            {
                IMC = Math.Round(Peso / Math.Pow(Altura, 2),1);

                txtIMC.Text = IMC.ToString();

                if (IMC < 18.5)
                {
                    MessageBox.Show("Classifica��o: Magresa");
                }
                else if (IMC < 24.9)
                {
                    MessageBox.Show("Classifica��o: Normal");
                }
                else if (IMC < 29.9)
                {
                    MessageBox.Show("Classifica��o: Sobrepeso");
                }
                else if (IMC < 39.9)
                {
                    MessageBox.Show("Classifica��o: Obesidade");
                }
                else
                {
                    MessageBox.Show("Classifica��o: Obesidade Grave");
                }
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            msktxAltura.Clear();
            msktxPeso.Clear();
            txtIMC.Clear();
            Peso = 0;
            Altura = 0;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja mesmo sair?", "Saida", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }
    }
}
