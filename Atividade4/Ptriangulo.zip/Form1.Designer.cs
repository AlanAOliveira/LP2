﻿namespace Ptriangulo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblValorA = new Label();
            lblValorB = new Label();
            lblValorC = new Label();
            txtValorA = new TextBox();
            txtValorB = new TextBox();
            txtValorC = new TextBox();
            btnExecuta = new Button();
            btnSair = new Button();
            SuspendLayout();
            // 
            // lblValorA
            // 
            lblValorA.AutoSize = true;
            lblValorA.Location = new Point(62, 30);
            lblValorA.Name = "lblValorA";
            lblValorA.Size = new Size(60, 15);
            lblValorA.TabIndex = 0;
            lblValorA.Text = "Valor de A";
            // 
            // lblValorB
            // 
            lblValorB.AutoSize = true;
            lblValorB.Location = new Point(62, 60);
            lblValorB.Name = "lblValorB";
            lblValorB.Size = new Size(59, 15);
            lblValorB.TabIndex = 1;
            lblValorB.Text = "Valor de B";
            // 
            // lblValorC
            // 
            lblValorC.AutoSize = true;
            lblValorC.Location = new Point(62, 94);
            lblValorC.Name = "lblValorC";
            lblValorC.Size = new Size(60, 15);
            lblValorC.TabIndex = 2;
            lblValorC.Text = "Valor de C";
            // 
            // txtValorA
            // 
            txtValorA.Location = new Point(144, 22);
            txtValorA.Name = "txtValorA";
            txtValorA.Size = new Size(100, 23);
            txtValorA.TabIndex = 3;
            // 
            // txtValorB
            // 
            txtValorB.Location = new Point(144, 57);
            txtValorB.Name = "txtValorB";
            txtValorB.Size = new Size(100, 23);
            txtValorB.TabIndex = 4;
            // 
            // txtValorC
            // 
            txtValorC.Location = new Point(144, 86);
            txtValorC.Name = "txtValorC";
            txtValorC.Size = new Size(100, 23);
            txtValorC.TabIndex = 5;
            // 
            // btnExecuta
            // 
            btnExecuta.Location = new Point(62, 162);
            btnExecuta.Name = "btnExecuta";
            btnExecuta.Size = new Size(75, 23);
            btnExecuta.TabIndex = 6;
            btnExecuta.Text = "Executa";
            btnExecuta.UseVisualStyleBackColor = true;
            btnExecuta.Click += btnExecuta_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(169, 162);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(75, 23);
            btnSair.TabIndex = 7;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnSair);
            Controls.Add(btnExecuta);
            Controls.Add(txtValorC);
            Controls.Add(txtValorB);
            Controls.Add(txtValorA);
            Controls.Add(lblValorC);
            Controls.Add(lblValorB);
            Controls.Add(lblValorA);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblValorA;
        private Label lblValorB;
        private Label lblValorC;
        private TextBox txtValorA;
        private TextBox txtValorB;
        private TextBox txtValorC;
        private Button btnExecuta;
        private Button btnSair;
    }
}
