namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecuta_Click(object sender, EventArgs e)
        {
            double A, B, C;
            string tipoTrinagulo;

            if (!double.TryParse(txtValorA.Text, out A))
            {
                MessageBox.Show("Valor de A Invalido! :0");
                txtValorA.Focus();
            }
            else if (!double.TryParse(txtValorB.Text, out B))
            {
                MessageBox.Show("Valor de B Invalido! :[");
                txtValorB.Focus();
            }
            else if (!double.TryParse(txtValorC.Text, out C))
            {
                MessageBox.Show("Valor de C Invalido! :<");
                txtValorC.Focus();
            }
            else
            {
                if ((Math.Abs(B - C) < A && A < (B + C)) && (Math.Abs(A - C) < B && B < (A + C)) && (Math.Abs(A - B) < C && C < (A + B)))
                {
                    if (A == B && A == C)
                    {
                        tipoTrinagulo = "Equilatero, onde os 3 lados e angulos sao iguais! :)";
                    }
                    else if ((A == B && A != C) || (B == C && B != A) || (C == A && C != B))
                    {
                        tipoTrinagulo = "Isoceles, onde os 2 lados e angulos sao iguais e um lado e angulo e diferete! :>";
                    }
                    else
                    {
                        tipoTrinagulo = "Escaleno, onde os 3 lados e angulos sao diferetes! :P";
                    }

                    MessageBox.Show("e um triangulo YEY! :3, do tipo:\n" + tipoTrinagulo);
                }
                else
                {
                    MessageBox.Show("Os valores informados nao formam um triangulo! ;-;");
                }

            }


        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja mesmo sair?", "Saida", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }
    }
}
