﻿namespace Pclasses
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnMensalista = new Button();
            btnHorista = new Button();
            SuspendLayout();
            // 
            // btnMensalista
            // 
            btnMensalista.Location = new Point(292, 190);
            btnMensalista.Name = "btnMensalista";
            btnMensalista.Size = new Size(112, 34);
            btnMensalista.TabIndex = 0;
            btnMensalista.Text = "Mensalista";
            btnMensalista.UseVisualStyleBackColor = true;
            btnMensalista.Click += btnMensalista_Click;
            // 
            // btnHorista
            // 
            btnHorista.Location = new Point(442, 190);
            btnHorista.Name = "btnHorista";
            btnHorista.Size = new Size(112, 34);
            btnHorista.TabIndex = 1;
            btnHorista.Text = "Horista";
            btnHorista.UseVisualStyleBackColor = true;
            btnHorista.Click += button2_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnHorista);
            Controls.Add(btnMensalista);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button btnMensalista;
        private Button btnHorista;
    }
}
