﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pclasses
{
    internal class Mensalista:Empregado
    {

        public Mensalista()
        {
            System.Windows.Forms.MessageBox.Show("Aqui é Mensalista");
        }

        public Mensalista(int matx, string nomex, DateTime datax, double salx)
        {
            this.NomeEmpregado = nomex;
            this.Matricula = matx;
            this.DataEntradaEmpresa = datax;
            this.SalarioMensal = salx;
        }

        public static String Empresa = "Toyota";
        public const String Filial = "Filial Sorocaba";

        public Double SalarioMensal
        {
            get; set;
        }
        public override double SalarioBruto()
        {
            return SalarioMensal;
        }
    }
}
