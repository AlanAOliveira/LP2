﻿namespace Pclasses
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnInstanciar2 = new Button();
            btnInstanciar1 = new Button();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtDataEntrada = new TextBox();
            txtSalario = new TextBox();
            txtNome = new TextBox();
            txtMatricula = new TextBox();
            label5 = new Label();
            label6 = new Label();
            txtFalta = new TextBox();
            txtHora = new TextBox();
            SuspendLayout();
            // 
            // btnInstanciar2
            // 
            btnInstanciar2.Location = new Point(394, 290);
            btnInstanciar2.Name = "btnInstanciar2";
            btnInstanciar2.Size = new Size(299, 89);
            btnInstanciar2.TabIndex = 19;
            btnInstanciar2.Text = "Instanciar Horista Passando Parametros";
            btnInstanciar2.UseVisualStyleBackColor = true;
            // 
            // btnInstanciar1
            // 
            btnInstanciar1.Location = new Point(108, 290);
            btnInstanciar1.Name = "btnInstanciar1";
            btnInstanciar1.Size = new Size(237, 89);
            btnInstanciar1.TabIndex = 18;
            btnInstanciar1.Text = "Instanciar Horista";
            btnInstanciar1.UseVisualStyleBackColor = true;
            btnInstanciar1.Click += btnInstanciar1_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(118, 158);
            label4.Name = "label4";
            label4.Size = new Size(187, 25);
            label4.TabIndex = 17;
            label4.Text = "Data Entrada Empresa";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(118, 83);
            label3.Name = "label3";
            label3.Size = new Size(109, 25);
            label3.TabIndex = 16;
            label3.Text = "Salário Hora";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(118, 46);
            label2.Name = "label2";
            label2.Size = new Size(61, 25);
            label2.TabIndex = 15;
            label2.Text = "Nome";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(118, 9);
            label1.Name = "label1";
            label1.Size = new Size(84, 25);
            label1.TabIndex = 14;
            label1.Text = "Matricula";
            // 
            // txtDataEntrada
            // 
            txtDataEntrada.Location = new Point(341, 158);
            txtDataEntrada.Name = "txtDataEntrada";
            txtDataEntrada.Size = new Size(362, 31);
            txtDataEntrada.TabIndex = 13;
            // 
            // txtSalario
            // 
            txtSalario.Location = new Point(341, 83);
            txtSalario.Name = "txtSalario";
            txtSalario.Size = new Size(362, 31);
            txtSalario.TabIndex = 12;
            // 
            // txtNome
            // 
            txtNome.Location = new Point(341, 46);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(362, 31);
            txtNome.TabIndex = 11;
            // 
            // txtMatricula
            // 
            txtMatricula.Location = new Point(341, 9);
            txtMatricula.Name = "txtMatricula";
            txtMatricula.Size = new Size(362, 31);
            txtMatricula.TabIndex = 10;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(120, 127);
            label5.Name = "label5";
            label5.Size = new Size(154, 25);
            label5.TabIndex = 20;
            label5.Text = "Numero de Horas";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(120, 201);
            label6.Name = "label6";
            label6.Size = new Size(112, 25);
            label6.TabIndex = 21;
            label6.Text = "Dias de Falta";
            // 
            // txtFalta
            // 
            txtFalta.Location = new Point(341, 195);
            txtFalta.Name = "txtFalta";
            txtFalta.Size = new Size(362, 31);
            txtFalta.TabIndex = 22;
            // 
            // txtHora
            // 
            txtHora.Location = new Point(341, 121);
            txtHora.Name = "txtHora";
            txtHora.Size = new Size(362, 31);
            txtHora.TabIndex = 23;
            // 
            // frmHorista
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(txtHora);
            Controls.Add(txtFalta);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(btnInstanciar2);
            Controls.Add(btnInstanciar1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtDataEntrada);
            Controls.Add(txtSalario);
            Controls.Add(txtNome);
            Controls.Add(txtMatricula);
            Name = "frmHorista";
            Text = "frmHorista";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnInstanciar2;
        private Button btnInstanciar1;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtDataEntrada;
        private TextBox txtSalario;
        private TextBox txtNome;
        private TextBox txtMatricula;
        private Label label5;
        private Label label6;
        private TextBox txtFalta;
        private TextBox txtHora;
    }
}