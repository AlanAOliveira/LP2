﻿namespace Pclasses
{
    partial class frmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtMatricula = new TextBox();
            txtNome = new TextBox();
            txtSalario = new TextBox();
            txtDataEntrada = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            btnInstanciar1 = new Button();
            btnInstanciar2 = new Button();
            SuspendLayout();
            // 
            // txtMatricula
            // 
            txtMatricula.Location = new Point(355, 21);
            txtMatricula.Name = "txtMatricula";
            txtMatricula.Size = new Size(362, 31);
            txtMatricula.TabIndex = 0;
            // 
            // txtNome
            // 
            txtNome.Location = new Point(355, 58);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(362, 31);
            txtNome.TabIndex = 1;
            // 
            // txtSalario
            // 
            txtSalario.Location = new Point(355, 95);
            txtSalario.Name = "txtSalario";
            txtSalario.Size = new Size(362, 31);
            txtSalario.TabIndex = 2;
            // 
            // txtDataEntrada
            // 
            txtDataEntrada.Location = new Point(355, 135);
            txtDataEntrada.Name = "txtDataEntrada";
            txtDataEntrada.Size = new Size(362, 31);
            txtDataEntrada.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(132, 21);
            label1.Name = "label1";
            label1.Size = new Size(84, 25);
            label1.TabIndex = 4;
            label1.Text = "Matricula";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(132, 58);
            label2.Name = "label2";
            label2.Size = new Size(61, 25);
            label2.TabIndex = 5;
            label2.Text = "Nome";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(132, 95);
            label3.Name = "label3";
            label3.Size = new Size(126, 25);
            label3.TabIndex = 6;
            label3.Text = "Salário Mensal";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(132, 135);
            label4.Name = "label4";
            label4.Size = new Size(187, 25);
            label4.TabIndex = 7;
            label4.Text = "Data Entrada Empresa";
            // 
            // btnInstanciar1
            // 
            btnInstanciar1.Location = new Point(132, 239);
            btnInstanciar1.Name = "btnInstanciar1";
            btnInstanciar1.Size = new Size(237, 89);
            btnInstanciar1.TabIndex = 8;
            btnInstanciar1.Text = "Instanciar Mensalista";
            btnInstanciar1.UseVisualStyleBackColor = true;
            btnInstanciar1.Click += btnInstanciar1_Click;
            // 
            // btnInstanciar2
            // 
            btnInstanciar2.Location = new Point(418, 239);
            btnInstanciar2.Name = "btnInstanciar2";
            btnInstanciar2.Size = new Size(299, 89);
            btnInstanciar2.TabIndex = 9;
            btnInstanciar2.Text = "Instanciar Mensalista Passando Parametros";
            btnInstanciar2.UseVisualStyleBackColor = true;
            btnInstanciar2.Click += btnInstanciar2_Click;
            // 
            // frmMensalista
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnInstanciar2);
            Controls.Add(btnInstanciar1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtDataEntrada);
            Controls.Add(txtSalario);
            Controls.Add(txtNome);
            Controls.Add(txtMatricula);
            Name = "frmMensalista";
            Text = "frmMensalista";
            Load += frmMensalista_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtMatricula;
        private TextBox txtNome;
        private TextBox txtSalario;
        private TextBox txtDataEntrada;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Button btnInstanciar1;
        private Button btnInstanciar2;
    }
}