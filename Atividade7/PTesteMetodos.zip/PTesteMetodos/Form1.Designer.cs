﻿namespace PTesteMetodos
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            exercicio2ToolStripMenuItem = new ToolStripMenuItem();
            copiarToolStripMenuItem = new ToolStripMenuItem();
            colarToolStripMenuItem = new ToolStripMenuItem();
            exercicio2ToolStripMenuItem1 = new ToolStripMenuItem();
            exercicio3ToolStripMenuItem = new ToolStripMenuItem();
            copiarToolStripMenuItem1 = new ToolStripMenuItem();
            colarToolStripMenuItem1 = new ToolStripMenuItem();
            exercicio4ToolStripMenuItem = new ToolStripMenuItem();
            exercicio5ToolStripMenuItem = new ToolStripMenuItem();
            sairToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(24, 24);
            menuStrip1.Items.AddRange(new ToolStripItem[] { exercicio2ToolStripMenuItem, exercicio3ToolStripMenuItem, exercicio4ToolStripMenuItem, exercicio5ToolStripMenuItem, sairToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Padding = new Padding(4, 1, 0, 1);
            menuStrip1.Size = new Size(560, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // exercicio2ToolStripMenuItem
            // 
            exercicio2ToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { copiarToolStripMenuItem, colarToolStripMenuItem, exercicio2ToolStripMenuItem1 });
            exercicio2ToolStripMenuItem.Name = "exercicio2ToolStripMenuItem";
            exercicio2ToolStripMenuItem.Size = new Size(72, 22);
            exercicio2ToolStripMenuItem.Text = "Exercicio2";
            exercicio2ToolStripMenuItem.Click += exercicio2ToolStripMenuItem_Click;
            // 
            // copiarToolStripMenuItem
            // 
            copiarToolStripMenuItem.Name = "copiarToolStripMenuItem";
            copiarToolStripMenuItem.Size = new Size(180, 22);
            copiarToolStripMenuItem.Text = "Copiar";
            copiarToolStripMenuItem.Click += copiarToolStripMenuItem_Click;
            // 
            // colarToolStripMenuItem
            // 
            colarToolStripMenuItem.Name = "colarToolStripMenuItem";
            colarToolStripMenuItem.Size = new Size(180, 22);
            colarToolStripMenuItem.Text = "Colar";
            colarToolStripMenuItem.Click += colarToolStripMenuItem_Click;
            // 
            // exercicio2ToolStripMenuItem1
            // 
            exercicio2ToolStripMenuItem1.Name = "exercicio2ToolStripMenuItem1";
            exercicio2ToolStripMenuItem1.Size = new Size(180, 22);
            exercicio2ToolStripMenuItem1.Text = "Exercicio2";
            // 
            // exercicio3ToolStripMenuItem
            // 
            exercicio3ToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { copiarToolStripMenuItem1, colarToolStripMenuItem1 });
            exercicio3ToolStripMenuItem.Name = "exercicio3ToolStripMenuItem";
            exercicio3ToolStripMenuItem.Size = new Size(72, 22);
            exercicio3ToolStripMenuItem.Text = "Exercicio3";
            exercicio3ToolStripMenuItem.Click += exercicio3ToolStripMenuItem_Click;
            // 
            // copiarToolStripMenuItem1
            // 
            copiarToolStripMenuItem1.Name = "copiarToolStripMenuItem1";
            copiarToolStripMenuItem1.Size = new Size(109, 22);
            copiarToolStripMenuItem1.Text = "Copiar";
            // 
            // colarToolStripMenuItem1
            // 
            colarToolStripMenuItem1.Name = "colarToolStripMenuItem1";
            colarToolStripMenuItem1.Size = new Size(109, 22);
            colarToolStripMenuItem1.Text = "Colar";
            // 
            // exercicio4ToolStripMenuItem
            // 
            exercicio4ToolStripMenuItem.Name = "exercicio4ToolStripMenuItem";
            exercicio4ToolStripMenuItem.Size = new Size(72, 22);
            exercicio4ToolStripMenuItem.Text = "Exercicio4";
            exercicio4ToolStripMenuItem.Click += exercicio4ToolStripMenuItem_Click;
            // 
            // exercicio5ToolStripMenuItem
            // 
            exercicio5ToolStripMenuItem.Name = "exercicio5ToolStripMenuItem";
            exercicio5ToolStripMenuItem.Size = new Size(72, 22);
            exercicio5ToolStripMenuItem.Text = "Exercicio5";
            exercicio5ToolStripMenuItem.Click += exercicio5ToolStripMenuItem_Click;
            // 
            // sairToolStripMenuItem
            // 
            sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            sairToolStripMenuItem.Size = new Size(38, 22);
            sairToolStripMenuItem.Text = "Sair";
            sairToolStripMenuItem.Click += sairToolStripMenuItem_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(560, 270);
            Controls.Add(menuStrip1);
            IsMdiContainer = true;
            MainMenuStrip = menuStrip1;
            Margin = new Padding(2);
            Name = "Form1";
            Text = "Form1";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem exercicio2ToolStripMenuItem;
        private ToolStripMenuItem exercicio3ToolStripMenuItem;
        private ToolStripMenuItem exercicio4ToolStripMenuItem;
        private ToolStripMenuItem exercicio5ToolStripMenuItem;
        private ToolStripMenuItem sairToolStripMenuItem;
        private ToolStripMenuItem copiarToolStripMenuItem;
        private ToolStripMenuItem colarToolStripMenuItem;
        private ToolStripMenuItem copiarToolStripMenuItem1;
        private ToolStripMenuItem colarToolStripMenuItem1;
        private ToolStripMenuItem exercicio2ToolStripMenuItem1;
    }
}
