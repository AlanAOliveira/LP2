﻿namespace PTesteMetodos
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnInverte = new Button();
            btnRemove = new Button();
            lblPalavra2 = new Label();
            lblPalavra1 = new Label();
            txtPalavra2 = new TextBox();
            txtPalavra1 = new TextBox();
            SuspendLayout();
            // 
            // btnInverte
            // 
            btnInverte.Location = new Point(325, 237);
            btnInverte.Name = "btnInverte";
            btnInverte.Size = new Size(150, 120);
            btnInverte.TabIndex = 12;
            btnInverte.Text = "Inverte";
            btnInverte.UseVisualStyleBackColor = true;
            btnInverte.Click += btnInverte_Click;
            // 
            // btnRemove
            // 
            btnRemove.Location = new Point(150, 237);
            btnRemove.Name = "btnRemove";
            btnRemove.Size = new Size(157, 120);
            btnRemove.TabIndex = 11;
            btnRemove.Text = "Remove 1º do 2º";
            btnRemove.UseVisualStyleBackColor = true;
            btnRemove.Click += btnRemove_Click;
            // 
            // lblPalavra2
            // 
            lblPalavra2.AutoSize = true;
            lblPalavra2.Location = new Point(225, 140);
            lblPalavra2.Name = "lblPalavra2";
            lblPalavra2.Size = new Size(82, 25);
            lblPalavra2.TabIndex = 10;
            lblPalavra2.Text = "Palavra 2";
            // 
            // lblPalavra1
            // 
            lblPalavra1.AutoSize = true;
            lblPalavra1.Location = new Point(225, 97);
            lblPalavra1.Name = "lblPalavra1";
            lblPalavra1.Size = new Size(82, 25);
            lblPalavra1.TabIndex = 9;
            lblPalavra1.Text = "Palavra 1";
            // 
            // txtPalavra2
            // 
            txtPalavra2.Location = new Point(338, 134);
            txtPalavra2.Name = "txtPalavra2";
            txtPalavra2.Size = new Size(150, 31);
            txtPalavra2.TabIndex = 8;
            // 
            // txtPalavra1
            // 
            txtPalavra1.Location = new Point(338, 94);
            txtPalavra1.Name = "txtPalavra1";
            txtPalavra1.Size = new Size(150, 31);
            txtPalavra1.TabIndex = 7;
            // 
            // frmExercicio3
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnInverte);
            Controls.Add(btnRemove);
            Controls.Add(lblPalavra2);
            Controls.Add(lblPalavra1);
            Controls.Add(txtPalavra2);
            Controls.Add(txtPalavra1);
            Name = "frmExercicio3";
            Text = "frmExercicio3";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnInverte;
        private Button btnRemove;
        private Label lblPalavra2;
        private Label lblPalavra1;
        private TextBox txtPalavra2;
        private TextBox txtPalavra1;
    }
}