﻿namespace PTesteMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            rchtxtFrase = new RichTextBox();
            btnContaNumero = new Button();
            btnEncontraEspaco = new Button();
            btnContaLetra = new Button();
            lblFrase = new Label();
            SuspendLayout();
            // 
            // rchtxtFrase
            // 
            rchtxtFrase.Location = new Point(71, 35);
            rchtxtFrase.Margin = new Padding(2);
            rchtxtFrase.Name = "rchtxtFrase";
            rchtxtFrase.Size = new Size(368, 88);
            rchtxtFrase.TabIndex = 0;
            rchtxtFrase.Text = "";
            // 
            // btnContaNumero
            // 
            btnContaNumero.Location = new Point(38, 134);
            btnContaNumero.Margin = new Padding(2);
            btnContaNumero.Name = "btnContaNumero";
            btnContaNumero.Size = new Size(122, 81);
            btnContaNumero.TabIndex = 1;
            btnContaNumero.Text = "Conta Numeros";
            btnContaNumero.UseVisualStyleBackColor = true;
            btnContaNumero.Click += btnContaNumero_Click;
            // 
            // btnEncontraEspaco
            // 
            btnEncontraEspaco.Location = new Point(191, 134);
            btnEncontraEspaco.Margin = new Padding(2);
            btnEncontraEspaco.Name = "btnEncontraEspaco";
            btnEncontraEspaco.Size = new Size(127, 81);
            btnEncontraEspaco.TabIndex = 2;
            btnEncontraEspaco.Text = "Encontra o primeiro espaço em branco";
            btnEncontraEspaco.UseVisualStyleBackColor = true;
            btnEncontraEspaco.Click += btnEncontraEspaco_Click;
            // 
            // btnContaLetra
            // 
            btnContaLetra.Location = new Point(344, 134);
            btnContaLetra.Margin = new Padding(2);
            btnContaLetra.Name = "btnContaLetra";
            btnContaLetra.Size = new Size(117, 81);
            btnContaLetra.TabIndex = 3;
            btnContaLetra.Text = "Conta Letras";
            btnContaLetra.UseVisualStyleBackColor = true;
            btnContaLetra.Click += btnContaLetra_Click;
            // 
            // lblFrase
            // 
            lblFrase.AutoSize = true;
            lblFrase.Location = new Point(71, 19);
            lblFrase.Margin = new Padding(2, 0, 2, 0);
            lblFrase.Name = "lblFrase";
            lblFrase.Size = new Size(90, 15);
            lblFrase.TabIndex = 4;
            lblFrase.Text = "Insira uma frase";
            // 
            // frmExercicio4
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(560, 270);
            Controls.Add(lblFrase);
            Controls.Add(btnContaLetra);
            Controls.Add(btnEncontraEspaco);
            Controls.Add(btnContaNumero);
            Controls.Add(rchtxtFrase);
            Margin = new Padding(2);
            Name = "frmExercicio4";
            Text = "frmExercicio4";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private RichTextBox rchtxtFrase;
        private Button btnContaNumero;
        private Button btnEncontraEspaco;
        private Button btnContaLetra;
        private Label lblFrase;
    }
}