﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnContaNumero_Click(object sender, EventArgs e)
        {
            int control = 0, numeros = 0;
            char[] vetor = rchtxtFrase.Text.ToCharArray();

            while (control < vetor.Length)
            {
                if (char.IsNumber(vetor[control]))
                {
                    numeros++;
                }
                control++;
            }

            MessageBox.Show($"a quantidade de numeros na string e: {numeros}");
        }

        private void btnEncontraEspaco_Click(object sender, EventArgs e)
        {
            int control = 0, blankspace = 0;
            char[] vetor = rchtxtFrase.Text.ToCharArray();

            while (control < vetor.Length)
            {
                if (char.IsWhiteSpace(vetor[control]))
                {
                    blankspace = control + 1;
                    break;
                }
                control++;
            }
            if (blankspace > 0)
            {
                MessageBox.Show($"o primeiro espaco em branco esta na posicao: {blankspace}");
            }
            else
            {
                MessageBox.Show("Sem espacos em branco");
            }


        }

        private void btnContaLetra_Click(object sender, EventArgs e)
        {
            int  letras = 0;
            char[] vetor = rchtxtFrase.Text.ToCharArray();

            foreach (char c in vetor)
            {
                if (char.IsLetter(c))
                {
                    letras++;
                }
            }

            MessageBox.Show($"a string tem {letras} caracteres de letra");
        }
    }
}
