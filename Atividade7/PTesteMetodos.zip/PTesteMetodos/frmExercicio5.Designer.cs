﻿namespace PTesteMetodos
{
    partial class frmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtNumero1 = new TextBox();
            txtNumero2 = new TextBox();
            lblNumero1 = new Label();
            lblNumero2 = new Label();
            btnTesta = new Button();
            SuspendLayout();
            // 
            // txtNumero1
            // 
            txtNumero1.Location = new Point(86, 11);
            txtNumero1.Name = "txtNumero1";
            txtNumero1.Size = new Size(100, 23);
            txtNumero1.TabIndex = 0;
            // 
            // txtNumero2
            // 
            txtNumero2.Location = new Point(307, 11);
            txtNumero2.Name = "txtNumero2";
            txtNumero2.Size = new Size(100, 23);
            txtNumero2.TabIndex = 1;
            // 
            // lblNumero1
            // 
            lblNumero1.AutoSize = true;
            lblNumero1.Location = new Point(23, 11);
            lblNumero1.Name = "lblNumero1";
            lblNumero1.Size = new Size(57, 15);
            lblNumero1.TabIndex = 2;
            lblNumero1.Text = "Numero1";
            // 
            // lblNumero2
            // 
            lblNumero2.AutoSize = true;
            lblNumero2.Location = new Point(244, 11);
            lblNumero2.Name = "lblNumero2";
            lblNumero2.Size = new Size(57, 15);
            lblNumero2.TabIndex = 3;
            lblNumero2.Text = "Numero2";
            // 
            // btnTesta
            // 
            btnTesta.Location = new Point(86, 55);
            btnTesta.Name = "btnTesta";
            btnTesta.Size = new Size(309, 115);
            btnTesta.TabIndex = 4;
            btnTesta.Text = "Testa Numeros";
            btnTesta.UseVisualStyleBackColor = true;
            btnTesta.Click += btnTesta_Click;
            // 
            // frmExercicio5
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(479, 255);
            Controls.Add(btnTesta);
            Controls.Add(lblNumero2);
            Controls.Add(lblNumero1);
            Controls.Add(txtNumero2);
            Controls.Add(txtNumero1);
            Name = "frmExercicio5";
            Text = "frmExercicio5";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtNumero1;
        private TextBox txtNumero2;
        private Label lblNumero1;
        private Label lblNumero2;
        private Button btnTesta;
    }
}