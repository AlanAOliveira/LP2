﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnTesta_Click(object sender, EventArgs e)
        {
            string texto1 = txtNumero1.Text, texto2 = txtNumero2.Text;
            int numero1, numero2, escolha;
            
            if(int.TryParse(texto1, out numero1) && int.TryParse(texto2, out numero2))
            {
                escolha = new Random().Next(numero1, numero2);
                MessageBox.Show($"aleatoriamete escolhido{escolha}");
                if (numero1 > numero2)
                {
                    MessageBox.Show("Numero 1 maior que numero 2");
                }
                else
                {
                    MessageBox.Show("Numero 1 nao e maior que numero 2");
                }

            }
            else
            {
                MessageBox.Show("um dos valores informados nao e numero");
            }
            
        }
    }
}
