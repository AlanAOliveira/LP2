﻿namespace PTesteLoops
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            exercicio1ToolStripMenuItem = new ToolStripMenuItem();
            exercicio2ToolStripMenuItem = new ToolStripMenuItem();
            exercicio3ToolStripMenuItem = new ToolStripMenuItem();
            exercicio4ToolStripMenuItem = new ToolStripMenuItem();
            sairToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { exercicio1ToolStripMenuItem, exercicio2ToolStripMenuItem, exercicio3ToolStripMenuItem, exercicio4ToolStripMenuItem, sairToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // exercicio1ToolStripMenuItem
            // 
            exercicio1ToolStripMenuItem.Name = "exercicio1ToolStripMenuItem";
            exercicio1ToolStripMenuItem.Size = new Size(72, 20);
            exercicio1ToolStripMenuItem.Text = "Exercicio1";
            exercicio1ToolStripMenuItem.Click += exercicio1ToolStripMenuItem_Click;
            // 
            // exercicio2ToolStripMenuItem
            // 
            exercicio2ToolStripMenuItem.Name = "exercicio2ToolStripMenuItem";
            exercicio2ToolStripMenuItem.Size = new Size(72, 20);
            exercicio2ToolStripMenuItem.Text = "Exercicio2";
            exercicio2ToolStripMenuItem.Click += exercicio2ToolStripMenuItem_Click;
            // 
            // exercicio3ToolStripMenuItem
            // 
            exercicio3ToolStripMenuItem.Name = "exercicio3ToolStripMenuItem";
            exercicio3ToolStripMenuItem.Size = new Size(72, 20);
            exercicio3ToolStripMenuItem.Text = "Exercicio3";
            exercicio3ToolStripMenuItem.Click += exercicio3ToolStripMenuItem_Click;
            // 
            // exercicio4ToolStripMenuItem
            // 
            exercicio4ToolStripMenuItem.Name = "exercicio4ToolStripMenuItem";
            exercicio4ToolStripMenuItem.Size = new Size(72, 20);
            exercicio4ToolStripMenuItem.Text = "Exercicio4";
            exercicio4ToolStripMenuItem.Click += exercicio4ToolStripMenuItem_Click;
            // 
            // sairToolStripMenuItem
            // 
            sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            sairToolStripMenuItem.Size = new Size(38, 20);
            sairToolStripMenuItem.Text = "Sair";
            sairToolStripMenuItem.Click += sairToolStripMenuItem_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(menuStrip1);
            IsMdiContainer = true;
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "Form1";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem exercicio1ToolStripMenuItem;
        private ToolStripMenuItem exercicio2ToolStripMenuItem;
        private ToolStripMenuItem exercicio3ToolStripMenuItem;
        private ToolStripMenuItem exercicio4ToolStripMenuItem;
        private ToolStripMenuItem sairToolStripMenuItem;
    }
}
