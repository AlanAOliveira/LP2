namespace PTesteLoops
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exercicio2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //form 2
            if (Application.OpenForms.OfType<btnGeraH>().Count() > 0)//tentar abrir formulario cujo nome seja frmExercicio2
            {
                Application.OpenForms["frmExercicio2"]?.BringToFront();//ou .Activate(); o activate da o foco no formulario
            }
            else
            {
                btnGeraH objFrm2 = new btnGeraH();//se o form ainda nao estiver rodado, cria um novo na mem�ria
                objFrm2.MdiParent = this;//filho do Form Principal (para n�o abrir em outra janela)
                objFrm2.WindowState = FormWindowState.Maximized;//deixa a janela do form maximizada
                objFrm2.Show();//mostrar o form exercicio 2
            }
        }

        private void exercicio1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //form 1
            if (Application.OpenForms.OfType<frmExercicio1>().Count() > 0)//tentar abrir formulario cujo nome seja frmExercicio1
            {
                Application.OpenForms["frmExercicio1"]?.BringToFront();//ou .Activate(); o activate da o foco no formulario
            }
            else
            {
                frmExercicio1 objFrm1 = new frmExercicio1();//se o form ainda nao estiver rodado, cria um novo na mem�ria
                objFrm1.MdiParent = this;//filho do Form Principal (para n�o abrir em outra janela)
                objFrm1.WindowState = FormWindowState.Maximized;//deixa a janela do form maximizada
                objFrm1.Show();//mostrar o form exercicio 1
            }
        }

        private void exercicio3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //form 3
            if (Application.OpenForms.OfType<frmExercicio3>().Count() > 0)//tentar abrir formulario cujo nome seja frmExercicio3
            {
                Application.OpenForms["frmExercicio3"]?.BringToFront();//ou .Activate(); o activate da o foco no formulario
            }
            else
            {
                frmExercicio3 objFrm3 = new frmExercicio3();//se o form ainda nao estiver rodado, cria um novo na mem�ria
                objFrm3.MdiParent = this;//filho do Form Principal (para n�o abrir em outra janela)
                objFrm3.WindowState = FormWindowState.Maximized;//deixa a janela do form maximizada
                objFrm3.Show();//mostrar o form exercicio 3
            }
        }

        private void exercicio4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //form 4
            if (Application.OpenForms.OfType<frmExercicio4>().Count() > 0)//tentar abrir formulario cujo nome seja frmExercicio4
            {
                Application.OpenForms["frmExercicio4"]?.BringToFront();//ou .Activate(); o activate da o foco no formulario
            }
            else
            {
                frmExercicio4 objFrm4 = new frmExercicio4();//se o form ainda nao estiver rodado, cria um novo na mem�ria
                objFrm4.MdiParent = this;//filho do Form Principal (para n�o abrir em outra janela)
                objFrm4.WindowState = FormWindowState.Maximized;//deixa a janela do form maximizada
                objFrm4.Show();//mostrar o form exercicio 4
            }
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
