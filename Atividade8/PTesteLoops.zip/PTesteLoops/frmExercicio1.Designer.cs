﻿namespace PTesteLoops
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            rchtxtTexto = new RichTextBox();
            btnBlankCount = new Button();
            btnCountR = new Button();
            CountDoubleLetters = new Button();
            SuspendLayout();
            // 
            // rchtxtTexto
            // 
            rchtxtTexto.Location = new Point(46, 63);
            rchtxtTexto.MaxLength = 100;
            rchtxtTexto.Name = "rchtxtTexto";
            rchtxtTexto.Size = new Size(392, 182);
            rchtxtTexto.TabIndex = 1;
            rchtxtTexto.Text = "";
            rchtxtTexto.TextChanged += richTextBox1_TextChanged;
            // 
            // btnBlankCount
            // 
            btnBlankCount.Location = new Point(475, 63);
            btnBlankCount.Name = "btnBlankCount";
            btnBlankCount.Size = new Size(257, 23);
            btnBlankCount.TabIndex = 2;
            btnBlankCount.Text = "Conta espacos em branco";
            btnBlankCount.UseVisualStyleBackColor = true;
            btnBlankCount.Click += btnBlankCount_Click;
            // 
            // btnCountR
            // 
            btnCountR.Location = new Point(475, 92);
            btnCountR.Name = "btnCountR";
            btnCountR.Size = new Size(257, 23);
            btnCountR.TabIndex = 3;
            btnCountR.Text = "Conta letras 'R'";
            btnCountR.UseVisualStyleBackColor = true;
            btnCountR.Click += btnCountR_Click;
            // 
            // CountDoubleLetters
            // 
            CountDoubleLetters.Location = new Point(475, 121);
            CountDoubleLetters.Name = "CountDoubleLetters";
            CountDoubleLetters.Size = new Size(257, 23);
            CountDoubleLetters.TabIndex = 4;
            CountDoubleLetters.Text = "Conta letras duplicadas";
            CountDoubleLetters.UseVisualStyleBackColor = true;
            CountDoubleLetters.Click += CountDoubleLetters_Click;
            // 
            // frmExercicio1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(CountDoubleLetters);
            Controls.Add(btnCountR);
            Controls.Add(btnBlankCount);
            Controls.Add(rchtxtTexto);
            Name = "frmExercicio1";
            Text = "frmExercicio1";
            ResumeLayout(false);
        }

        #endregion

        private RichTextBox rchtxtTexto;
        private Button btnBlankCount;
        private Button btnCountR;
        private Button CountDoubleLetters;
    }
}