﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteLoops
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnBlankCount_Click(object sender, EventArgs e)
        {
            string texto = rchtxtTexto.Text;
            int count = 0;
            for (int i = 0; i < texto.Length; i++)
            {
                if (char.IsWhiteSpace(texto[i]))
                {
                    count++;
                }
            }
            MessageBox.Show($"O texto tem {count} espacos em branco");
        }

        private void btnCountR_Click(object sender, EventArgs e)
        {
            string textoupper = rchtxtTexto.Text.ToUpper();
            char[] texto = textoupper.ToCharArray();
            int count = 0, i = 0;
            foreach (char c in texto)
            {
                if (c == 'R')
                {
                    count++;
                }
                i++;
            }
            MessageBox.Show($"O texto tem {count} letras 'R'");
        }

        private void CountDoubleLetters_Click(object sender, EventArgs e)
        {
            string texto = rchtxtTexto.Text.ToUpper();
            int count = 0, i = 0;
            while(i< (texto.Length - 1))
            {
                if (texto[i] == texto[i+1])
                {
                    count++;
                }
                i++;
            }
            MessageBox.Show($"O texto tem {count} letras duplicadas");
        }
    }
}
