﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteLoops
{
    public partial class btnGeraH : Form
    {
        public btnGeraH()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int num = 0;
            double result = 0.0;
            if(int.TryParse(txtN.Text, out num) && num > 0)
            {
                for(int i = 1; i <= num; i++)
                {
                    result = result + (1.0/i);
                }
                MessageBox.Show($"Somando as divisoes sucessivas de 1 por 1 ate {num} " +
                    $"geram o valor e {result}");
            }
            else
            {
                MessageBox.Show("Insira um valor numerico Maior que 0");
            }
        }
    }
}
