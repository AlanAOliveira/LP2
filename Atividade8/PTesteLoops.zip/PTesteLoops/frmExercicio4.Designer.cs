﻿namespace PTesteLoops
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtNome = new TextBox();
            txtMatricula = new TextBox();
            txtProducao = new TextBox();
            txtSalario = new TextBox();
            txtGratificacao = new TextBox();
            lblNome = new Label();
            lblMatricula = new Label();
            lblProducao = new Label();
            lblSalario = new Label();
            lblGratificacao = new Label();
            btnCalculaSalario = new Button();
            SuspendLayout();
            // 
            // txtNome
            // 
            txtNome.Location = new Point(173, 151);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(100, 23);
            txtNome.TabIndex = 0;
            // 
            // txtMatricula
            // 
            txtMatricula.Location = new Point(173, 180);
            txtMatricula.Name = "txtMatricula";
            txtMatricula.Size = new Size(100, 23);
            txtMatricula.TabIndex = 1;
            // 
            // txtProducao
            // 
            txtProducao.Location = new Point(173, 209);
            txtProducao.Name = "txtProducao";
            txtProducao.Size = new Size(100, 23);
            txtProducao.TabIndex = 2;
            // 
            // txtSalario
            // 
            txtSalario.Location = new Point(173, 238);
            txtSalario.Name = "txtSalario";
            txtSalario.Size = new Size(100, 23);
            txtSalario.TabIndex = 3;
            // 
            // txtGratificacao
            // 
            txtGratificacao.Location = new Point(173, 267);
            txtGratificacao.Name = "txtGratificacao";
            txtGratificacao.Size = new Size(100, 23);
            txtGratificacao.TabIndex = 4;
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Location = new Point(93, 154);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(40, 15);
            lblNome.TabIndex = 5;
            lblNome.Text = "Nome";
            lblNome.Click += label1_Click;
            // 
            // lblMatricula
            // 
            lblMatricula.AutoSize = true;
            lblMatricula.Location = new Point(93, 183);
            lblMatricula.Name = "lblMatricula";
            lblMatricula.Size = new Size(57, 15);
            lblMatricula.TabIndex = 6;
            lblMatricula.Text = "Matricula";
            // 
            // lblProducao
            // 
            lblProducao.AutoSize = true;
            lblProducao.Location = new Point(93, 212);
            lblProducao.Name = "lblProducao";
            lblProducao.Size = new Size(58, 15);
            lblProducao.TabIndex = 7;
            lblProducao.Text = "Producao";
            // 
            // lblSalario
            // 
            lblSalario.AutoSize = true;
            lblSalario.Location = new Point(93, 241);
            lblSalario.Name = "lblSalario";
            lblSalario.Size = new Size(42, 15);
            lblSalario.TabIndex = 8;
            lblSalario.Text = "Salario";
            // 
            // lblGratificacao
            // 
            lblGratificacao.AutoSize = true;
            lblGratificacao.Location = new Point(93, 270);
            lblGratificacao.Name = "lblGratificacao";
            lblGratificacao.Size = new Size(70, 15);
            lblGratificacao.TabIndex = 9;
            lblGratificacao.Text = "Gratificacao";
            // 
            // btnCalculaSalario
            // 
            btnCalculaSalario.Location = new Point(324, 151);
            btnCalculaSalario.Name = "btnCalculaSalario";
            btnCalculaSalario.Size = new Size(127, 72);
            btnCalculaSalario.TabIndex = 10;
            btnCalculaSalario.Text = "Calcular Salario";
            btnCalculaSalario.UseVisualStyleBackColor = true;
            btnCalculaSalario.Click += btnCalculaSalario_Click;
            // 
            // frmExercicio4
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnCalculaSalario);
            Controls.Add(lblGratificacao);
            Controls.Add(lblSalario);
            Controls.Add(lblProducao);
            Controls.Add(lblMatricula);
            Controls.Add(lblNome);
            Controls.Add(txtGratificacao);
            Controls.Add(txtSalario);
            Controls.Add(txtProducao);
            Controls.Add(txtMatricula);
            Controls.Add(txtNome);
            Name = "frmExercicio4";
            Text = "frmExercicio4";
            Load += lblratificacao_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtNome;
        private TextBox txtMatricula;
        private TextBox txtProducao;
        private TextBox txtSalario;
        private TextBox txtGratificacao;
        private Label lblNome;
        private Label lblMatricula;
        private Label lblProducao;
        private Label lblSalario;
        private Label lblGratificacao;
        private Button btnCalculaSalario;
    }
}