﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteLoops
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnCalculaSalario_Click(object sender, EventArgs e)
        {
            double SalarioBruto, B = 0, C = 0, D = 0, SalarioBase, Producao, Gratificacao;
            double.TryParse(txtSalario.Text, out SalarioBase);
            double.TryParse(txtProducao.Text, out Producao);
            double.TryParse(txtGratificacao.Text, out Gratificacao);

            if (Producao >= 150)
            {
                D = C = B = 1;

            }
            else if (Producao >= 120)
            {
                C = B = 1;
            }
            else if (Producao >= 100)
            {
                B = 1;
            }

            SalarioBruto = SalarioBase + SalarioBase * (0.05 * B + 0.1 * C + 0.1 * D) + Gratificacao;
            if (SalarioBruto <= 7000)
            {
                MessageBox.Show($"O Salario e R${SalarioBruto}");
            }
            else
            {
                if (Gratificacao > 0 && Producao >= 150)
                {
                    MessageBox.Show($"O Salario e R${SalarioBruto}");
                }
                else
                {
                    MessageBox.Show($"O Salario e R$ 7000");
                }
            }



        }

        private void lblratificacao_Load(object sender, EventArgs e)
        {

        }
    }
}
