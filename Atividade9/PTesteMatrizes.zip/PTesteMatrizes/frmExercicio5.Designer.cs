﻿namespace PTesteMatrizes
{
    partial class frmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnExecutar = new Button();
            lstbxRespostas = new ListBox();
            SuspendLayout();
            // 
            // btnExecutar
            // 
            btnExecutar.Location = new Point(118, 59);
            btnExecutar.Name = "btnExecutar";
            btnExecutar.Size = new Size(196, 140);
            btnExecutar.TabIndex = 0;
            btnExecutar.Text = "Executar";
            btnExecutar.UseVisualStyleBackColor = true;
            btnExecutar.Click += btnExecutar_Click;
            // 
            // lstbxRespostas
            // 
            lstbxRespostas.FormattingEnabled = true;
            lstbxRespostas.ItemHeight = 15;
            lstbxRespostas.Location = new Point(417, 59);
            lstbxRespostas.Name = "lstbxRespostas";
            lstbxRespostas.Size = new Size(248, 214);
            lstbxRespostas.TabIndex = 1;
            // 
            // frmExercicio5
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lstbxRespostas);
            Controls.Add(btnExecutar);
            Name = "frmExercicio5";
            Text = "frmExercicio5";
            ResumeLayout(false);
        }

        #endregion

        private Button btnExecutar;
        private ListBox lstbxRespostas;
    }
}