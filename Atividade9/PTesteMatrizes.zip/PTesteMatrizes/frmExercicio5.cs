﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            char[] respostas = { 'A', 'E', 'B', 'C', 'D', 'A', 'E', 'B', 'C', 'D' };
            string auxiliar, correcao; 

            for (int i = 0; i < respostas.Length; i++) {

                auxiliar = Interaction.InputBox($"Digite a resposta da pergunta:{i + 1}", "Entrada de dados");
                if (auxiliar.ToUpper().ToCharArray()[0] == respostas[i])
                {
                    correcao = "Correta";
                }
                else
                {
                    correcao = "Errada";
                }
                lstbxRespostas.Items.Add($"Pergunta {i + 1} sua resposta {auxiliar.ToCharArray()[0]} resultado:{correcao}");
                correcao = "";
            }


        }
    }
}
