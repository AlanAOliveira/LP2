using Microsoft.VisualBasic;
using System.Configuration;

namespace PAluno
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            lstbxNotas.Items.Clear();
            double[,] notas = new double[8, 3];
            double nota, media;
            string entradaNota, saidaNota = "";

            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    saidaNota = "";
                    entradaNota = Interaction.InputBox($"Digite a nota {j + 1},para o aluno :{i + 1}", "Entrada de Notas");
                    if (!double.TryParse(entradaNota, out nota))
                    {
                        j--;
                        MessageBox.Show("Favor informar uma nota valida valor numerico");
                    }
                    else if ((nota < 0 || nota > 10))
                    {
                        j--;
                        MessageBox.Show("Favor informar uma nota valida entre 0 e 10");
                    }
                    else
                    {
                        notas[i,j] = nota;
                    }

                }
                media = (notas[i, 0] + notas[i, 1] + notas[i, 2]) / 3;
                saidaNota += $"Aluno {i + 1} ";
                for (int k = 0; k< 3; k++)
                {
                    saidaNota += $"Nota Professor {k+1}: {notas[i, k].ToString("0.00")} ";
                } 
                saidaNota +=$"Media {media.ToString("0.00")}";
                lstbxNotas.Items.Add(saidaNota);

            }
            saidaNota = "";
            media = 0.00;
            foreach (var item in notas)
            {
                media += item;
            }
            media = media / notas.Length;
            lstbxNotas.Items.Add("------------------------------");
            lstbxNotas.Items.Add($"Media Geral Alunos: {media.ToString("0.00")}");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {         
            lstbxNotas.Items.Clear();
        }
    }
}
