﻿namespace Pvolume
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtRaio = new TextBox();
            txtAltura = new TextBox();
            txtVolume = new TextBox();
            lblRaio = new Label();
            lblAltura = new Label();
            lblVolume = new Label();
            btnCalcular = new Button();
            btnFechar = new Button();
            SuspendLayout();
            // 
            // txtRaio
            // 
            txtRaio.Location = new Point(160, 29);
            txtRaio.Name = "txtRaio";
            txtRaio.Size = new Size(150, 31);
            txtRaio.TabIndex = 0;
            txtRaio.Validated += txtRaio_Validated;
            // 
            // txtAltura
            // 
            txtAltura.Location = new Point(160, 92);
            txtAltura.Name = "txtAltura";
            txtAltura.Size = new Size(150, 31);
            txtAltura.TabIndex = 1;
            txtAltura.Validated += txtAltura_Validated;
            // 
            // txtVolume
            // 
            txtVolume.Enabled = false;
            txtVolume.Location = new Point(160, 159);
            txtVolume.Name = "txtVolume";
            txtVolume.ReadOnly = true;
            txtVolume.Size = new Size(150, 31);
            txtVolume.TabIndex = 2;
            // 
            // lblRaio
            // 
            lblRaio.AutoSize = true;
            lblRaio.Location = new Point(73, 32);
            lblRaio.Name = "lblRaio";
            lblRaio.Size = new Size(47, 25);
            lblRaio.TabIndex = 3;
            lblRaio.Text = "Raio";
            // 
            // lblAltura
            // 
            lblAltura.AutoSize = true;
            lblAltura.Location = new Point(73, 104);
            lblAltura.Name = "lblAltura";
            lblAltura.Size = new Size(59, 25);
            lblAltura.TabIndex = 4;
            lblAltura.Text = "Altura";
            // 
            // lblVolume
            // 
            lblVolume.AutoSize = true;
            lblVolume.Location = new Point(73, 165);
            lblVolume.Name = "lblVolume";
            lblVolume.Size = new Size(72, 25);
            lblVolume.TabIndex = 5;
            lblVolume.Text = "Volume";
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(73, 313);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(112, 34);
            btnCalcular.TabIndex = 6;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnFechar
            // 
            btnFechar.Location = new Point(254, 313);
            btnFechar.Name = "btnFechar";
            btnFechar.Size = new Size(112, 34);
            btnFechar.TabIndex = 7;
            btnFechar.Text = "Fechar";
            btnFechar.UseVisualStyleBackColor = true;
            btnFechar.Click += btnFechar_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(465, 396);
            Controls.Add(btnFechar);
            Controls.Add(btnCalcular);
            Controls.Add(lblVolume);
            Controls.Add(lblAltura);
            Controls.Add(lblRaio);
            Controls.Add(txtVolume);
            Controls.Add(txtAltura);
            Controls.Add(txtRaio);
            Name = "Form1";
            Text = "Calculo do Volume do Cilindro";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtRaio;
        private TextBox txtAltura;
        private TextBox txtVolume;
        private Label lblRaio;
        private Label lblAltura;
        private Label lblVolume;
        private Button btnCalcular;
        private Button btnFechar;
    }
}
