namespace Pvolume
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double Volume, Raio, Altura;

            if (!double.TryParse(txtRaio.Text, out Raio) || !double.TryParse(txtAltura.Text, out Altura))
            {
                MessageBox.Show("Valores Invalidos");
                txtRaio.Focus();
            }
            else
            {
                Volume = Math.PI * Math.Pow(Raio, 2) * Altura;
                txtVolume.Text = Volume.ToString("N2");
            }


        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            double Raio;
            if (!double.TryParse(txtRaio.Text, out Raio))
            {
                MessageBox.Show("Raio Invalido");
            }
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            double Altura;

            if (!double.TryParse(txtAltura.Text, out Altura))
            {
                MessageBox.Show("Raio Invalido");
            }
        }


    }
}
